flatcssbuttons
==============

Flatcssbuttons library for social media and css buttons that work with font-awesome and decrease development time

Flat CSS Buttons
* CSS - Only (no images) 
* 3 sizes (Large, Medium, Small)
* 3 types (square, round, oval)
* 21 Different colors * Works in button, a, input tags
* 4 Theme Color Palettes
* Social Media Icons with Font-Awesome
* Works in FireFox, Safari, Chrome, Opera, IE9 and up

Works with Bootstrap and Foundation front-end frameworks
